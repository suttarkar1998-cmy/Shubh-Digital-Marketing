# Shubh Digital Marketing — Website + CMS

This folder has everything for your live website AND a free admin panel
where you can edit text, pricing, testimonials, stats and social links
from your browser — no coding needed.

## What's in this folder
- `index.html` — the website itself (now includes SEO meta tags, Open Graph tags, and structured data)
- `content.json` — all the editable text/numbers on the site (the admin panel edits this file)
- `admin/` — the admin panel (Decap CMS), now using GitHub login instead of the deprecated Netlify Identity
- `robots.txt` — tells search engines they're allowed to crawl the site
- `sitemap.xml` — helps Google find and index your page

## IMPORTANT: update your real domain
Search the following files for `https://www.shubhdigitalmarketing.in/` and replace
it with your actual live domain once you have one (Netlify's `.netlify.app`
address works fine too):
- `index.html` (canonical link, Open Graph tags, structured data)
- `robots.txt`
- `sitemap.xml`

## One-time setup (about 15 minutes)

### 1. Put this folder on GitHub
1. Go to https://github.com and create a free account if you don't have one.
2. Create a new repository (e.g. `shubh-website`).
3. Upload all the files in this folder to that repository, keeping the
   `admin` folder structure exactly as it is.

### 2. Connect the repo to Netlify
1. In Netlify, choose **Add new site → Import an existing project**.
2. Connect your GitHub account and pick the repository you just created.
3. Leave the build settings empty (no build command needed) and deploy.

### 3. Set up GitHub login for the admin panel
Netlify's old Identity + Git Gateway login is deprecated and unreliable for
new sites, so this version uses GitHub directly instead:
1. Go to `github.com/settings/developers` → OAuth Apps → **New OAuth App**.
   - Homepage URL: your Netlify site URL
   - Authorization callback URL: `https://api.netlify.com/auth/done`
2. Click **Generate a new client secret** and copy the Client ID and Secret.
3. In Netlify, go to **Site configuration → Access & security → OAuth →
   Install provider**, choose GitHub, and paste in the Client ID and Secret.
4. Open `admin/config.yml` and replace `YOUR_GITHUB_USERNAME/YOUR_REPO_NAME`
   with your actual GitHub username and repo name, then upload the updated
   file to GitHub.

### 4. Open the admin panel
Go to `https://your-site-name.netlify.app/admin/`. Click **Login with
GitHub**, authorize the app, and you'll land in the content editor —
hero text, pricing, testimonials, stats, and social links. Hit **Publish**
after editing, and the live site updates automatically within a minute or two.

## Day-to-day editing
Once set up, you never need to touch code again:
1. Visit `/admin/` on your site.
2. Log in with GitHub.
3. Edit any field.
4. Click **Publish**.

## On-page & technical SEO already built in
- Meta title, description, keywords, canonical tag
- Open Graph + Twitter Card tags (for link previews when shared)
- JSON-LD structured data (`MarketingAgency` schema, helps Google understand
  your business type, phone number, and service area)
- `robots.txt` + `sitemap.xml` for crawlability
- Single H1 per page, proper heading hierarchy, semantic HTML
- Mobile-responsive, fast-loading (no heavy frameworks)

Bring the changes back to this chat any time you want a bigger redesign,
more SEO work (e.g. a blog section for content marketing, more schema types,
per-page metadata if you add more pages) — I can always give you a fresh,
ready-to-upload version.
